const express = require('express');
const Route = express.Router;

module.exports = Route;
