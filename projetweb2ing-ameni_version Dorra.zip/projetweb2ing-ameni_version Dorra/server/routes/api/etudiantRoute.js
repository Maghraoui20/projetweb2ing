const express = require('express');
const router = express.Router();
const etudiantController = require('../../controllers/etudiantController')
const Auth = require('../../middleware/Auth')

router.use(Auth.validate);
router.get('/',etudiantController.index);
router.get('/get',etudiantController.getEtudiants);
router.get('/add',etudiantController.addEtudiant);
router.get('/delete/:id',etudiantController.deleteEtudiant);
module.exports = router;
