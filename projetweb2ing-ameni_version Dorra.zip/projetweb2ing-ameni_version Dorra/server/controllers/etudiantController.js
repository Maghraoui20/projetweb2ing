const etudiant = require('../models/etudiant');
class etudiantController {
    static index(req, res){
       res.send("Hello form etudiantController");
    }
    static async getEtudiants (req,res){
        try{
            await etudiant.find({}).then(result=>{
                   res.send(result);
                })
            }catch (err) {
                console.log(err)
            } 
            
    }
    static async addEtudiant (req, res){
        try{
            let new_etudiant = new etudiant({
                cin:req.body.cin,
                date_emission_cin: req.body.date_emission_cin,
                lieu_emission_cin: req.body.lieu_emission_cin,
                nom: req.body.nom,
                prenom: req.body.prenom,
                email: req.body.email,
                genre: req.body.genre,
                date_naissance: req.body.date_naissance,
                lieu_naissance: req.body.lieu_naissance,
                niveau: req.body.niveau,
                filiere: req.body.filiere,
                specialtite: req.body.specialtite,
                adresse: req.body.adresse,
                code_postal: req.body.code_postal,
                gouvernorat: req.body.gouvernorat,
                pays: req.body.pays,
                passport: req.body.passport,
                etat_civil: req.body.etat_civil,
                annee_bac: req.body.annee_bac,
                section_bac: res.body.section_bac,
                mention_bac: req.body.mention_bac,
                session_bac: req.body.session_bac,
                pays_bac: req.body.pays_bac,
                type_inscription: req.body.type_inscription,
                telephone: req.body.telephone,
                profession: req.body.profession,
                nom_pere: req.body.nom_pere,
                profession_pere: req.body.profession_pere,
                insitution_pere: req.body.insitution_pere,
                adresse_pere: req.body.adresse_pere,
                tel_pere: req.body.tel_pere,
                nom_mere: res.body.nom_mere,
                profession_mere: req.body.profession_mere,
                insitution_mere: req.body.insitution_mere,
                adresse_mere: req.body.adresse_mere,
                tel_mere: req.body.tel_mere,
                photo: req.body.photo,
                role: req.body.role
            });
            await new_etudiant.save();
            res.send("save fait avec succes")
        }catch(err){
            console.log(err);
        }
        
    }
    static async deleteEtudiants (req,res){
        try{
            await etudiant.findByIdAndDelete({id:req.body.id});
            res.send("supprime en succes !");
            }catch (err) {
                res.send(err);
            } 
            
    }
    
}

module.exports = etudiantController;