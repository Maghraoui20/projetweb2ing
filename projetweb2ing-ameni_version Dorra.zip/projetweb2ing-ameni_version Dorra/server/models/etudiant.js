const mongoose = require('mongoose')


const etudiantSchema = new mongoose.Schema({
    cin: {
        type: Number,
        required: false,
    },
    date_emission_cin: {
        type: Date,
        required: false,
    },
    lieu_emission_cin: {
        type: String,
        required: false,
    },
    nom: {
        type: String,
        required: true,
    },
    prenom: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },
    genre: {
        type: String,
        required: true,
    },
    date_naissance: {
        type: Date,
        required: true,
    },
    lieu_naissance: {
        type: String,
        required: true,
    },
    niveau: {
        type: Number,
        default: 1
    },
    filiere: {
        type: String,
        required: true,
    },
    specialtite: {
        type: String,
        required: true,
    },
    adresse: {
        type: String,
        required: true,
    },
    code_postal: {
        type: Number,
        required: true,
    },
    gouvernorat: {
        type: String,
        required: true,
    },
    pays: {
        type: String,
        required: true,
    },
    passport:{
        type: String,
        required: false,
    },
    etat_civil: {
        type: String,
        required: true,
    },
    annee_bac: {
        type: Number,
        required: true,
    },
    section_bac: {
        type: String,
        required: true,
    },
    mention_bac: {
        type: String,
        required: true,
    },
    session_bac: {
        type: String,
        required: true,
    },
    pays_bac: {
        type: String,
        required: true,
    },
    type_inscription: {
        type: String,
        required: true,
    },
    telephone: {
        type: Number,
        required: true,
    },
    profession: {
        type: String,
        required: false,
    },
    nom_pere: {
        type: String,
        required: true,  
    },
    profession_pere: {
        type: String,
        required: true,  
    },
    insitution_pere: {
        type: String,
        required: true,  
    },
    adresse_pere: {
        type: String,
        required: true,  
    },
    tel_pere: {
        type: String,
        required: true,  
    },
    nom_mere: {
        type: String,
        required: true,  
    },
    profession_mere: {
        type: String,
        required: true,  
    },
    insitution_mere: {
        type: String,
        required: true,  
    },
    adresse_mere: {
        type: String,
        required: true,  
    },
    tel_mere: {
        type: String,
        required: true,  
    },
    photo:{
        type: String,
        required: true,
    },
    role: {
        type: String,
        default: 'courant',
    }
}, {
    timestamps: true
})


module.exports = mongoose.model('etudiant', etudiantSchema)