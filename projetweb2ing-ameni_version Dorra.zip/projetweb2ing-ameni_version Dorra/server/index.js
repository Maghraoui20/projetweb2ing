const express  = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose')
const cors = require('cors')
const etudiant = require('./models/etudiant');
const etudiantRoute = require('./routes/api/etudiantRoute');



var app = express();
app.use(etudiantRoute);

app.use(bodyParser.json({ limit: "40mb", extended: true }));
app.use(bodyParser.urlencoded({ limit: "40mb", extended: true }));
app.use(bodyParser.json());
app.use(cors());

const CONNECTION_URL = 'mongodb+srv://2ingweb:2ingweb@cluster0.l4xvlhw.mongodb.net/?retryWrites=true&w=majority';

mongoose.connect(
    CONNECTION_URL,
    (err, done) => {
        if (err) {
            console.log(err);
        }
        if (done) {
            console.log("Base de données connectés avec succès !");
        }
    }
);


//mongoose.set('strictQuery', false);
app.listen(5030, ()=> console.log("Serveur en marche !"));

